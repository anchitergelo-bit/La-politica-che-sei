export type AxisId = "economico" | "culturale" | "sovranita";

export type Likert = -2 | -1 | 0 | 1 | 2;

export type Question = {
  id: string;
  tema: string;
  testo: string;
  nota?: string;
  /** +1: d'accordo spinge a destra; -1: d'accordo spinge a sinistra */
  polarity: 1 | -1;
  axes: Record<AxisId, number>;
};

export type Party = {
  id: string;
  name: string;
  short: string;
  family: string;
  economico: number;
  culturale: number;
  sovranita: number;
  blurb: string;
};

export type AxisScores = Record<AxisId, number>;

export type BandId =
  | "estrema-sinistra"
  | "sinistra"
  | "centro-sinistra"
  | "centro"
  | "centro-destra"
  | "destra"
  | "destra-nazionale";

export type QuizResult = {
  overall: number;
  axes: AxisScores;
  band: BandId;
  matches: Array<{ party: Party; score: number }>;
  answers: Record<string, Likert>;
};

export const LIKERT_VALUES: Likert[] = [-2, -1, 0, 1, 2];

export const AXIS_META: Record<
  AxisId,
  { label: string; left: string; right: string; blurb: string }
> = {
  economico: {
    label: "Economia",
    left: "Stato e redistribuzione",
    right: "Mercato e tasse basse",
    blurb:
      "Chi deve pesare di più: la spesa pubblica, i sindacati, il welfare — o impresa, partite IVA, taglio del cuneo.",
  },
  culturale: {
    label: "Società",
    left: "Diritti e laicità",
    right: "Tradizione e ordine",
    blurb:
      "Famiglia, scuola, 194, identità di genere, memoria pubblica: il perimetro del lecito e del normale.",
  },
  sovranita: {
    label: "Sovranità",
    left: "Europa e alleanze",
    right: "Nazione e confini",
    blurb:
      "Bruxelles, NATO, migranti, autonomie: quanto l'Italia deve vincolarsi all'esterno e quanto chiudere il perimetro.",
  },
};
