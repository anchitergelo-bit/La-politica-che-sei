import { PARTIES } from "./parties";
import { QUESTIONS } from "./questions";
import type {
  AxisId,
  AxisScores,
  BandId,
  Likert,
  Party,
  QuizResult,
} from "./types";

const AXES: AxisId[] = ["economico", "culturale", "sovranita"];

const BANDS: Array<{ id: BandId; max: number }> = [
  { id: "estrema-sinistra", max: -68 },
  { id: "sinistra", max: -42 },
  { id: "centro-sinistra", max: -16 },
  { id: "centro", max: 16 },
  { id: "centro-destra", max: 42 },
  { id: "destra", max: 68 },
  { id: "destra-nazionale", max: 200 },
];

export function bandFromScore(overall: number): BandId {
  for (const band of BANDS) {
    if (overall <= band.max) return band.id;
  }
  return "destra-nazionale";
}

export function scoreQuiz(answers: Record<string, Likert>): QuizResult {
  const contrib: AxisScores = { economico: 0, culturale: 0, sovranita: 0 };
  const weight: AxisScores = { economico: 0, culturale: 0, sovranita: 0 };

  for (const q of QUESTIONS) {
    const answer = answers[q.id];
    if (answer === undefined) continue;
    for (const axis of AXES) {
      const w = q.axes[axis];
      contrib[axis] += answer * q.polarity * w;
      weight[axis] += 2 * w;
    }
  }

  const axes: AxisScores = { economico: 0, culturale: 0, sovranita: 0 };
  for (const axis of AXES) {
    axes[axis] = weight[axis] === 0 ? 0 : (100 * contrib[axis]) / weight[axis];
  }

  const overall = axes.economico * 0.38 + axes.culturale * 0.4 + axes.sovranita * 0.22;
  const matches = rankParties(axes);
  return { overall, axes, band: bandFromScore(overall), matches, answers };
}

function rankParties(axes: AxisScores): Array<{ party: Party; score: number }> {
  return PARTIES.map((party) => {
    const dist = Math.hypot(
      axes.economico - party.economico,
      axes.culturale - party.culturale,
      axes.sovranita - party.sovranita,
    );
    const max = Math.hypot(200, 200, 200);
    const score = Math.max(0, Math.min(100, 100 * (1 - dist / max)));
    return { party, score };
  }).sort((a, b) => b.score - a.score);
}

export const BAND_COPY: Record<
  BandId,
  { title: string; kicker: string; body: string }
> = {
  "estrema-sinistra": {
    title: "Sinistra radicale",
    kicker: "Il banco è in fondo a sinistra",
    body: "Redistribuzione, diritti civili, pace e transizione: lo Stato deve spostare il baricentro, non accomodarsi al mercato. Nell'emiciclo odierno sei vicino ad AVS e alla sinistra di conflitto.",
  },
  sinistra: {
    title: "Sinistra",
    kicker: "Welfare, diritti, Europa sociale",
    body: "Non sei per la rivoluzione, ma il mercato da solo non ti basta. Salario, casa, 194, cittadinanza: la politica deve correggere. Il PD di Schlein e i Verdi ti somigliano più di Calenda o Meloni.",
  },
  "centro-sinistra": {
    title: "Centro-sinistra",
    kicker: "Riformista, europeista, laico",
    body: "Preferisci correzioni al sistema, non un cambio di regime. Diritti e welfare sì, nazionalizzazioni e sovranismo no. È il territorio storico del PD, con sconfinamenti verso M5S o il centro riformista.",
  },
  centro: {
    title: "Centro",
    kicker: "Né pullover rosso né tricolore in giacca",
    body: "Le tue risposte non si fanno catturare da un solo polo. Può essere pragmatismo, ibridazione (mercato + diritti, o Stato + tradizione) o semplice rifiuto delle tribù. In Parlamento oggi è un posto scomodo.",
  },
  "centro-destra": {
    title: "Centro-destra",
    kicker: "Impresa, ordine, europeismo cauto",
    body: "Tasse più basse, legalità, famiglia come cornice — senza spezzare i ponti con Bruxelles e la NATO. È il registro di Forza Italia, e di chi nel centro-destra non vuole la guerra culturale tutti i giorni.",
  },
  destra: {
    title: "Destra",
    kicker: "Confini, identità, governo forte",
    body: "Sovranità, sicurezza, tradizione: lo Stato c'è, ma per chi sta dentro il perimetro. Lega e Fratelli d'Italia ti sono più vicini del PD; l'Europa è un vincolo da ridiscutere, non una patria.",
  },
  "destra-nazionale": {
    title: "Destra nazionale",
    kicker: "Nazione prima di tutto",
    body: "Identità, ordine, premierato, respingimenti: il quadro è quello di Fratelli d'Italia, con la Lega a fare da cassa di risonanza sovranista. La sinistra istituzionale ti appare un'altra Repubblica.",
  },
};

export function profileNote(result: QuizResult): string {
  const { economico, culturale, sovranita } = result.axes;
  const econLeft = economico < -20;
  const econRight = economico > 20;
  const cultLeft = culturale < -20;
  const cultRight = culturale > 20;
  const euro = sovranita < -20;
  const sovran = sovranita > 20;

  if (econLeft && cultRight) {
    return "Profilo ibrido: interventista in economia, conservatore sui costumi. In Italia è il terreno di una parte del M5S e di un elettorato popolare che non si riconosce nel PD laico né nel liberismo di Azione.";
  }
  if (econRight && cultLeft) {
    return "Profilo liberale: mercato e diritti, NATO e laicità. È la nicchia di Azione e +Europa — influente nel dibattito, stretta alle urne.";
  }
  if (econLeft && cultLeft && euro) {
    return "Coerente a sinistra su tutti e tre gli assi: spesa, diritti, Europa. Pochi salti mortali, molte distanze dalla maggioranza di governo.";
  }
  if (econRight && cultRight && sovran) {
    return "Coerente a destra su tutti e tre gli assi: fisco, costumi, nazione. È il blocco che ha vinto nel 2022, con sfumature fra FI, Lega e FdI.";
  }
  if (sovran && cultLeft) {
    return "Sovranista sui confini, progressista sui diritti: combinazione rara nei partiti, più frequente fra gli elettori delusi da entrambi i poli.";
  }
  if (euro && cultRight) {
    return "Europeista e socialmente conservatore: il vecchio centro-destra berlusconiano, oggi minoranza dentro una destra più identitaria.";
  }
  if (Math.abs(result.overall) < 12) {
    return "Le distanze fra gli assi si compensano: il verdetto «centro» nasconde magari una sinistra economica e una destra culturale, o il contrario. Guarda le tre barre, non solo il titolo.";
  }
  return "Il titolo è una sintesi. Le tre barre sotto dicono se sei lineare o se, come succede spesso in Italia, sei di una parte sull'economia e dell'altra sui costumi.";
}

export function overallLabel(score: number): string {
  if (score < -8) return "sinistra";
  if (score > 8) return "destra";
  return "centro";
}
