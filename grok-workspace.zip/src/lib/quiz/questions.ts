import type { Question } from "./types";

export const QUESTIONS: Question[] = [
  {
    id: "flat-tax",
    tema: "Fisco",
    testo:
      "L'Italia dovrebbe introdurre una flat tax: un'aliquota unica, più bassa, per tutti i redditi.",
    nota: "È la bandiera storica della Lega e di parte del centro-destra.",
    polarity: 1,
    axes: { economico: 1, culturale: 0.1, sovranita: 0.15 },
  },
  {
    id: "ius-scholae",
    tema: "Cittadinanza",
    testo:
      "Chi nasce in Italia o ci studia per un ciclo intero dovrebbe diventare cittadino con una procedura semplice, senza aspettare i diciotto anni.",
    nota: "Ius scholae / ius soli: spaccatura classica fra PD, AVS, M5S e il centro-destra.",
    polarity: -1,
    axes: { economico: 0.05, culturale: 0.7, sovranita: 0.55 },
  },
  {
    id: "sicurezza",
    tema: "Sicurezza",
    testo:
      "Per stazioni, piazze e periferie servono più poteri alle forze dell'ordine, pene più certe e meno indulgenza verso reati di strada.",
    polarity: 1,
    axes: { economico: 0.1, culturale: 0.85, sovranita: 0.25 },
  },
  {
    id: "salario-minimo",
    tema: "Lavoro",
    testo:
      "Serve un salario minimo legale, anche se sindacati e Confindustria preferiscono lasciare tutto ai contratti.",
    polarity: -1,
    axes: { economico: 1, culturale: 0.15, sovranita: 0 },
  },
  {
    id: "famiglia",
    tema: "Famiglia",
    testo:
      "Lo Stato deve privilegiare la famiglia fondata sul matrimonio tra uomo e donna, non equiparare ogni forma di unione.",
    polarity: 1,
    axes: { economico: 0.05, culturale: 1, sovranita: 0.15 },
  },
  {
    id: "clima",
    tema: "Ambiente",
    testo:
      "La transizione ecologica va accelerata anche se nel breve pesa su auto, industria e bollette.",
    polarity: -1,
    axes: { economico: 0.55, culturale: 0.45, sovranita: 0.1 },
  },
  {
    id: "premierato",
    tema: "Istituzioni",
    testo:
      "Un premierato — presidente del Consiglio eletto, più stabile e più forte — renderebbe l'Italia meglio governabile.",
    nota: "Riforma costituzionale cara a Fratelli d'Italia; la sinistra la legge come rischio autoritario.",
    polarity: 1,
    axes: { economico: 0.1, culturale: 0.35, sovranita: 0.7 },
  },
  {
    id: "reddito",
    tema: "Welfare",
    testo:
      "Uno strumento strutturale di reddito minimo (nello spirito del reddito di cittadinanza) va difeso: senza, troppe persone restano indietro.",
    polarity: -1,
    axes: { economico: 1, culturale: 0.2, sovranita: 0.05 },
  },
  {
    id: "toghe",
    tema: "Giustizia",
    testo:
      "Separare le carriere di giudici e pubblici ministeri e ridurre il peso della magistratura sulla politica è una riforma urgente.",
    polarity: 1,
    axes: { economico: 0.15, culturale: 0.55, sovranita: 0.35 },
  },
  {
    id: "194",
    tema: "Diritti",
    testo:
      "La legge 194 va applicata per intero: meno obiettori di fatto, più accesso reale all'interruzione di gravidanza.",
    polarity: -1,
    axes: { economico: 0.05, culturale: 1, sovranita: 0.05 },
  },
  {
    id: "bruxelles",
    tema: "Europa",
    testo:
      "L'Italia deve recuperare sovranità su bilancio, confini e regole, anche a costo di uno scontro con Bruxelles.",
    polarity: 1,
    axes: { economico: 0.25, culturale: 0.2, sovranita: 1 },
  },
  {
    id: "articolo-18",
    tema: "Lavoro",
    testo:
      "Va ripristinata una tutela forte contro i licenziamenti, nello spirito dell'articolo 18.",
    polarity: -1,
    axes: { economico: 1, culturale: 0.2, sovranita: 0 },
  },
  {
    id: "autonomia",
    tema: "Autonomie",
    testo:
      "Le Regioni più efficienti devono poter tenere più tasse e gestire da sole sanità, scuola e infrastrutture.",
    nota: "Autonomia differenziata: priorità della Lega, osteggiata da M5S, PD e da gran parte del Sud.",
    polarity: 1,
    axes: { economico: 0.35, culturale: 0.1, sovranita: 0.7 },
  },
  {
    id: "armi",
    tema: "Esteri",
    testo:
      "L'Italia deve ridurre la spesa militare e uscire dalla logica dei blocchi, privilegiando la diplomazia sulla spedizione di armi.",
    polarity: -1,
    axes: { economico: 0.15, culturale: 0.25, sovranita: 0.85 },
  },
  {
    id: "nazione",
    tema: "Identità",
    testo:
      "L'Italia deve smettere di vergognarsi della propria storia nazionale e mettere bandiera, tradizione e identità al centro della vita pubblica.",
    polarity: 1,
    axes: { economico: 0, culturale: 0.75, sovranita: 0.7 },
  },
  {
    id: "casa",
    tema: "Casa",
    testo:
      "Affitti, case popolari, limiti agli affitti brevi: la casa è un diritto, non può restare in mano al solo mercato.",
    polarity: -1,
    axes: { economico: 0.9, culturale: 0.2, sovranita: 0.05 },
  },
  {
    id: "nucleare",
    tema: "Energia",
    testo:
      "L'Italia deve tornare al nucleare per avere energia stabile e meno dipendenza dal gas.",
    polarity: 1,
    axes: { economico: 0.55, culturale: 0.15, sovranita: 0.35 },
  },
  {
    id: "scuola",
    tema: "Scuola",
    testo:
      "A scuola non si deve parlare di identità di genere: l'educazione dei figli spetta alla famiglia, non allo Stato.",
    polarity: 1,
    axes: { economico: 0, culturale: 1, sovranita: 0.15 },
  },
  {
    id: "stato-economia",
    tema: "Economia",
    testo:
      "Lo Stato deve tornare a pesare di più nell'economia: partecipazioni pubbliche, controllo dei prezzi, nazionalizzazioni se serve.",
    polarity: -1,
    axes: { economico: 1, culturale: 0.1, sovranita: 0.2 },
  },
  {
    id: "migranti",
    tema: "Confini",
    testo:
      "L'Italia deve respingere i barconi, esternalizzare i centri (Albania o Africa) e rendere più difficile lo sbarco.",
    polarity: 1,
    axes: { economico: 0.15, culturale: 0.55, sovranita: 0.9 },
  },
];
