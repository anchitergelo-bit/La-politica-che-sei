import type { Party } from "./types";

/** Posizioni indicative sul dibattito 2022–2026, non un sondaggio. Scala −100…+100. */
export const PARTIES: Party[] = [
  {
    id: "avs",
    name: "Alleanza Verdi e Sinistra",
    short: "AVS",
    family: "Sinistra radicale",
    economico: -74,
    culturale: -80,
    sovranita: -58,
    blurb:
      "Ecologista, femminista, pacifista. Salario minimo, 194 piena, no al nucleare, scettica sulla NATO.",
  },
  {
    id: "pd",
    name: "Partito Democratico",
    short: "PD",
    family: "Centro-sinistra",
    economico: -40,
    culturale: -58,
    sovranita: -52,
    blurb:
      "Europeista e atlantista. Ius scholae, welfare, transizione; più cauto su nazionalizzazioni e reddito universale.",
  },
  {
    id: "m5s",
    name: "Movimento 5 Stelle",
    short: "M5S",
    family: "Populismo di sinistra",
    economico: -58,
    culturale: -16,
    sovranita: -6,
    blurb:
      "Reddito, ambiente, pace. Ostile all'autonomia differenziata; più trasversale sui temi etici e sull'Europa.",
  },
  {
    id: "azione",
    name: "Azione / +Europa",
    short: "Azione",
    family: "Centro riformista",
    economico: 24,
    culturale: -46,
    sovranita: -64,
    blurb:
      "Liberale, atlantista, nucleare e mercato. Progressista sui diritti, intransigente con i conti pubblici.",
  },
  {
    id: "fi",
    name: "Forza Italia",
    short: "FI",
    family: "Centro-destra liberale",
    economico: 50,
    culturale: 22,
    sovranita: 6,
    blurb:
      "Basse tasse, impresa, NATO e UE. Conservatore morbido su famiglia e ordine, europeista nel metodo.",
  },
  {
    id: "lega",
    name: "Lega",
    short: "Lega",
    family: "Destra sovranista",
    economico: 30,
    culturale: 58,
    sovranita: 80,
    blurb:
      "Confini, autonomia regionale, flat tax. Scettica su Bruxelles e sui diritti civili, più ambigua sulla NATO.",
  },
  {
    id: "fdi",
    name: "Fratelli d'Italia",
    short: "FdI",
    family: "Destra nazionale",
    economico: 40,
    culturale: 74,
    sovranita: 76,
    blurb:
      "Nazione, famiglia, ordine, premierato. Mercato con Stato strategico; dura su migranti e identità.",
  },
];
