import { useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Landing } from "@/components/quiz/landing";
import { QuestionView } from "@/components/quiz/question-view";
import { Results } from "@/components/quiz/results";
import { QUESTIONS } from "@/lib/quiz/questions";
import { scoreQuiz } from "@/lib/quiz/scoring";
import type { Likert, QuizResult } from "@/lib/quiz/types";

export const Route = createFileRoute("/")({ component: Home });

const STORAGE_KEY = "emiciclo-result-v1";

type Screen = "home" | "quiz" | "results";

function Home() {
  const [screen, setScreen] = useState<Screen>("home");
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, Likert>>({});
  const [result, setResult] = useState<QuizResult | null>(null);
  const [saved, setSaved] = useState<QuizResult | null>(null);
  const advanceRef = useRef<number | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as QuizResult;
      if (parsed && typeof parsed.overall === "number" && parsed.band) {
        setSaved(parsed);
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    return () => {
      if (advanceRef.current !== null) window.clearTimeout(advanceRef.current);
    };
  }, []);

  function clearAdvance() {
    if (advanceRef.current !== null) {
      window.clearTimeout(advanceRef.current);
      advanceRef.current = null;
    }
  }

  function start() {
    clearAdvance();
    setAnswers({});
    setIndex(0);
    setResult(null);
    setScreen("quiz");
  }

  function choose(value: Likert) {
    const q = QUESTIONS[index];
    if (!q) return;
    const from = index;
    const nextAnswers = { ...answers, [q.id]: value };
    setAnswers(nextAnswers);
    clearAdvance();
    advanceRef.current = window.setTimeout(() => {
      if (from + 1 >= QUESTIONS.length) {
        const scored = scoreQuiz(nextAnswers);
        setResult(scored);
        setSaved(scored);
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(scored));
        } catch {
          /* ignore */
        }
        setScreen("results");
      } else {
        setIndex(from + 1);
      }
    }, 160);
  }

  function back() {
    clearAdvance();
    if (index === 0) {
      setScreen("home");
      return;
    }
    setIndex((i) => i - 1);
  }

  return (
    <main className="paper-grain min-h-dvh bg-paper text-ink">
      {screen === "home" ? (
        <Landing
          onStart={start}
          hasSaved={Boolean(saved)}
          onResumeResult={() => {
            if (saved) {
              setResult(saved);
              setScreen("results");
            }
          }}
        />
      ) : null}
      {screen === "quiz" ? (
        <QuestionView
          index={index}
          value={answers[QUESTIONS[index]?.id ?? ""]}
          onChoose={choose}
          onBack={back}
        />
      ) : null}
      {screen === "results" && result ? (
        <Results result={result} onRetake={start} />
      ) : null}
    </main>
  );
}
