import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-sans font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-smooth focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]",
  {
    variants: {
      variant: {
        primary:
          "bg-ink text-paper shadow-[0_1px_0_rgb(23_21_19_/_0.2)] hover:bg-ink-soft",
        outline:
          "bg-transparent text-ink ring-1 ring-ink/15 hover:bg-ink/[0.04] hover:ring-ink/25",
        ghost: "bg-transparent text-ink hover:bg-ink/[0.05]",
        inverse: "bg-paper text-ink hover:bg-paper-2",
      },
      size: {
        md: "h-11 rounded-lg px-5 text-sm",
        lg: "h-12 rounded-xl px-7 text-base",
        sm: "h-9 rounded-md px-3.5 text-sm",
        icon: "size-11 rounded-lg",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  },
);

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
  };

export function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: ButtonProps) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  );
}
