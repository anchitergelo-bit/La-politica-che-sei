import { RotateCcw } from "lucide-react";
import { AXIS_META, type AxisId } from "@/lib/quiz/types";
import { BAND_COPY, overallLabel, profileNote } from "@/lib/quiz/scoring";
import type { QuizResult } from "@/lib/quiz/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Hemicycle } from "./hemicycle";

const AXES: AxisId[] = ["economico", "culturale", "sovranita"];

type Props = {
  result: QuizResult;
  onRetake: () => void;
};

export function Results({ result, onRetake }: Props) {
  const copy = BAND_COPY[result.band];
  const side = overallLabel(result.overall);
  const top = result.matches.slice(0, 4);

  return (
    <div className="mx-auto w-full max-w-2xl px-5 pb-20 pt-8 sm:px-8 sm:pt-12">
      <header className="flex items-baseline justify-between border-b border-line pb-3">
        <p className="font-display text-xl font-medium tracking-tight">Emiciclo</p>
        <p className="text-[0.7rem] font-medium uppercase tracking-[0.18em] text-muted">
          Esito
        </p>
      </header>

      <p className="enter mt-10 text-[0.7rem] font-medium uppercase tracking-[0.18em] text-muted">
        {copy.kicker}
      </p>
      <h1 className="enter enter-d1 mt-3 font-display text-[2.35rem] font-medium leading-[1.1] tracking-[-0.03em] sm:text-5xl">
        {copy.title}
      </h1>
      <p className="enter enter-d2 mt-2 font-display text-xl italic text-muted">
        Per la politica italiana sei di {side}.
      </p>

      <div className="enter enter-d3 mt-8">
        <Hemicycle position={result.overall} className="mx-auto max-w-md" />
        <Spectrum score={result.overall} />
      </div>

      <p className="enter enter-d4 mt-8 text-[1.05rem] leading-relaxed text-ink-soft">
        {copy.body}
      </p>
      <p className="mt-4 text-sm leading-relaxed text-muted">{profileNote(result)}</p>

      <section className="mt-12">
        <h2 className="text-[0.7rem] font-medium uppercase tracking-[0.16em] text-muted">
          Tre assi
        </h2>
        <div className="mt-4 flex flex-col gap-6">
          {AXES.map((axis) => (
            <AxisBar key={axis} axis={axis} value={result.axes[axis]} />
          ))}
        </div>
      </section>

      <section className="mt-12">
        <h2 className="text-[0.7rem] font-medium uppercase tracking-[0.16em] text-muted">
          Il banco più vicino
        </h2>
        <ul className="mt-4 flex flex-col gap-px overflow-hidden rounded-xl bg-line shadow-card">
          {top.map((m, i) => (
            <li key={m.party.id} className="flex items-start gap-4 bg-surface px-4 py-4 sm:px-5">
              <span
                className={cn(
                  "mt-0.5 w-8 shrink-0 font-display text-lg tabular-nums",
                  i === 0 ? "text-ink" : "text-faint",
                )}
              >
                {Math.round(m.score)}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                  <p className="font-medium">{m.party.name}</p>
                  <p className="text-xs text-faint">{m.party.family}</p>
                </div>
                <p className="mt-1 text-sm leading-relaxed text-muted">{m.party.blurb}</p>
              </div>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-faint">
          Affinità 0–100 sulla distanza fra i tuoi tre assi e la posizione
          indicativa del partito. Non è un consiglio di voto.
        </p>
      </section>

      <div className="mt-12 flex flex-col gap-3 sm:flex-row">
        <Button size="lg" onClick={onRetake} className="w-full sm:w-auto">
          <RotateCcw className="size-4" strokeWidth={2} />
          Rifai il test
        </Button>
      </div>
    </div>
  );
}

function Spectrum({ score }: { score: number }) {
  const left = ((score + 100) / 200) * 100;
  return (
    <div className="mx-auto mt-2 max-w-md">
      <div className="relative h-1.5 overflow-hidden rounded-full bg-linear-to-r from-crimson via-paper-3 to-navy">
        <span
          className="absolute top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-ink ring-2 ring-paper"
          style={{ left: `${left}%` }}
        />
      </div>
      <div className="mt-2 flex justify-between text-[0.65rem] font-medium uppercase tracking-[0.14em] text-faint">
        <span>Sinistra</span>
        <span className="tabular-nums text-ink/70">{fmt(score)}</span>
        <span>Destra</span>
      </div>
    </div>
  );
}

function AxisBar({ axis, value }: { axis: AxisId; value: number }) {
  const meta = AXIS_META[axis];
  const mid = 50;
  const pos = ((value + 100) / 200) * 100;
  const from = Math.min(mid, pos);
  const width = Math.abs(pos - mid);

  return (
    <div>
      <div className="flex items-baseline justify-between gap-3">
        <p className="font-medium">{meta.label}</p>
        <p className="text-xs tabular-nums text-muted">{fmt(value)}</p>
      </div>
      <p className="mt-0.5 text-xs text-faint">{meta.blurb}</p>
      <div className="relative mt-3 h-2 rounded-full bg-paper-3">
        <div
          className={cn(
            "bar-in absolute top-0 h-2 rounded-full",
            value < 0 ? "bg-crimson origin-right" : "bg-navy origin-left",
          )}
          style={{ left: `${from}%`, width: `${Math.max(width, value === 0 ? 0 : 1.5)}%` }}
        />
        <span className="absolute top-1/2 left-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-ink/30" />
      </div>
      <div className="mt-1.5 flex justify-between text-[0.65rem] text-faint">
        <span>{meta.left}</span>
        <span>{meta.right}</span>
      </div>
    </div>
  );
}

function fmt(n: number): string {
  const v = Math.round(n);
  if (v > 0) return `+${v}`;
  return `${v}`;
}
