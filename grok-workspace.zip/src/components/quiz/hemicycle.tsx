import { cn } from "@/lib/utils";

const CRIMSON = "#8b2e2e";
const NAVY = "#1f3a5f";
const STONE = "#c4b8a6";

type Seat = {
  x: number;
  y: number;
  t: number;
  r: number;
};

function round(n: number): number {
  return Math.round(n * 100) / 100;
}

function buildSeats(): Seat[] {
  const rows = [11, 14, 17, 21, 25];
  const seats: Seat[] = [];
  rows.forEach((count, row) => {
    const radius = 52 + row * 16;
    for (let i = 0; i < count; i++) {
      const t = count === 1 ? 0.5 : i / (count - 1);
      const a = Math.PI - t * Math.PI;
      seats.push({
        x: round(200 + Math.cos(a) * radius),
        y: round(178 - Math.sin(a) * radius),
        t: round(t * 1000) / 1000,
        r: row === 0 ? 3.1 : 3.4,
      });
    }
  });
  return seats;
}

const SEATS = buildSeats();

function seatFill(t: number): string {
  if (t < 0.45) return mix(CRIMSON, STONE, t / 0.45);
  if (t > 0.55) return mix(STONE, NAVY, (t - 0.55) / 0.45);
  return STONE;
}

function mix(a: string, b: string, t: number): string {
  const pa = hex(a);
  const pb = hex(b);
  const m = (i: number) => Math.round(pa[i] + (pb[i] - pa[i]) * t);
  return `rgb(${m(0)} ${m(1)} ${m(2)})`;
}

function hex(h: string): [number, number, number] {
  return [
    parseInt(h.slice(1, 3), 16),
    parseInt(h.slice(3, 5), 16),
    parseInt(h.slice(5, 7), 16),
  ];
}

type Props = {
  position?: number;
  className?: string;
  marked?: boolean;
};

export function Hemicycle({ position, className, marked = true }: Props) {
  const tUser =
    position === undefined ? null : Math.min(1, Math.max(0, (position + 100) / 200));
  let closest = 0;
  if (tUser !== null) {
    let best = 1;
    SEATS.forEach((s, i) => {
      const d = Math.abs(s.t - tUser);
      if (d < best) {
        best = d;
        closest = i;
      }
    });
  }

  return (
    <svg
      viewBox="0 0 400 200"
      className={cn("w-full", className)}
      role="img"
      aria-label={
        tUser === null
          ? "Emiciclo parlamentare vuoto"
          : "La tua posizione nell'emiciclo"
      }
    >
      <path
        d="M 42 178 A 158 158 0 0 1 358 178"
        fill="none"
        stroke="currentColor"
        strokeOpacity="0.08"
        strokeWidth="1"
      />
      {SEATS.map((seat, i) => {
        const isMark = marked && tUser !== null && i === closest;
        return (
          <circle
            key={`${seat.x}-${seat.y}-${i}`}
            cx={seat.x}
            cy={seat.y}
            r={isMark ? seat.r + 2.2 : seat.r}
            fill={isMark ? "var(--color-ink)" : seatFill(seat.t)}
            opacity={isMark ? 1 : 0.92}
          />
        );
      })}
      <rect
        x="168"
        y="176"
        width="64"
        height="8"
        rx="1"
        fill="var(--color-ink)"
        opacity="0.88"
      />
    </svg>
  );
}
