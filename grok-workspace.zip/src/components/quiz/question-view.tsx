import { ChevronLeft } from "lucide-react";
import { QUESTIONS } from "@/lib/quiz/questions";
import type { Likert } from "@/lib/quiz/types";
import { LIKERT_VALUES } from "@/lib/quiz/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const END_LABELS: Record<Likert, string> = {
  [-2]: "No",
  [-1]: "Più no",
  [0]: "Neutrale",
  [1]: "Più sì",
  [2]: "Sì",
};

type Props = {
  index: number;
  value?: Likert;
  onChoose: (value: Likert) => void;
  onBack: () => void;
};

export function QuestionView({ index, value, onChoose, onBack }: Props) {
  const q = QUESTIONS[index];
  const total = QUESTIONS.length;
  const progress = ((index + (value !== undefined ? 1 : 0)) / total) * 100;

  if (!q) return null;

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-5 pb-10 pt-6 sm:px-8">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          className="size-11 shrink-0"
          onClick={onBack}
          aria-label={index === 0 ? "Torna all'inizio" : "Domanda precedente"}
        >
          <ChevronLeft className="size-5" />
        </Button>
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between gap-3">
            <p className="text-[0.7rem] font-medium uppercase tracking-[0.16em] text-muted">
              {q.tema}
            </p>
            <p className="font-sans text-xs tabular-nums text-faint">
              {index + 1} / {total}
            </p>
          </div>
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-paper-3">
            <div
              className="h-full rounded-full bg-ink transition-[width] duration-fast ease-smooth"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      <div key={q.id} className="enter mt-10 flex flex-1 flex-col sm:mt-14">
        <h1 className="font-display text-[1.65rem] font-medium leading-snug tracking-[-0.02em] sm:text-[2rem]">
          {q.testo}
        </h1>
        {q.nota ? (
          <p className="mt-4 max-w-lg text-sm leading-relaxed text-muted">{q.nota}</p>
        ) : null}

        <div className="mt-10 sm:mt-12">
          <p
            className="mb-5 min-h-6 text-center text-sm font-medium text-ink"
            aria-live="polite"
          >
            {value !== undefined ? END_LABELS[value] : "Scegli una posizione"}
          </p>
          <div
            role="radiogroup"
            aria-label="Quanto sei d'accordo"
            className="flex items-end justify-between gap-1 sm:gap-2"
          >
            {LIKERT_VALUES.map((v) => {
              const selected = value === v;
              const size =
                v === 0
                  ? "size-11 sm:size-12"
                  : v === -1 || v === 1
                    ? "size-12 sm:size-14"
                    : "size-14 sm:size-16";
              return (
                <button
                  key={v}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  aria-label={END_LABELS[v]}
                  onClick={() => onChoose(v)}
                  className="flex min-h-11 min-w-11 flex-col items-center gap-2 rounded-2xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
                >
                  <span
                    className={cn(
                      "rounded-full border transition-[background-color,border-color,transform,box-shadow] duration-150 ease-smooth",
                      size,
                      selected
                        ? "border-ink bg-ink shadow-[0_0_0_4px_rgb(23_21_19_/_0.12)]"
                        : "border-ink/25 bg-surface hover:border-ink/50 hover:bg-paper-2",
                    )}
                  />
                </button>
              );
            })}
          </div>
          <div className="mt-3 flex justify-between text-[0.7rem] font-medium uppercase tracking-[0.14em] text-faint">
            <span>In disaccordo</span>
            <span>D'accordo</span>
          </div>
        </div>
      </div>
    </div>
  );
}
