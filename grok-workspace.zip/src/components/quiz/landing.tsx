import { ArrowRight, Clock3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Hemicycle } from "./hemicycle";

type Props = {
  onStart: () => void;
  hasSaved: boolean;
  onResumeResult: () => void;
};

export function Landing({ onStart, hasSaved, onResumeResult }: Props) {
  return (
    <div className="relative mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-5 pb-16 pt-8 sm:px-8 sm:pt-12">
      <header className="enter flex items-baseline justify-between border-b border-line pb-3">
        <p className="font-display text-xl font-medium tracking-tight">Emiciclo</p>
        <p className="text-[0.7rem] font-medium uppercase tracking-[0.18em] text-muted">
          Politica italiana
        </p>
      </header>

      <div className="enter enter-d1 mt-10 sm:mt-14">
        <Hemicycle marked={false} className="mx-auto max-w-md text-ink" />
      </div>

      <div className="enter enter-d2 mt-8 sm:mt-10">
        <p className="text-[0.7rem] font-medium uppercase tracking-[0.18em] text-muted">
          Test di orientamento
        </p>
        <h1 className="mt-3 font-display text-[2.15rem] font-medium leading-[1.12] tracking-[-0.03em] text-ink sm:text-5xl">
          Di che parte sei,
          <br />
          <span className="italic">davvero</span>?
        </h1>
        <p className="mt-5 max-w-md text-[1.05rem] leading-relaxed text-muted">
          Non un meme da social. Venti domande sul dibattito italiano di questi
          anni — tasse, migranti, 194, Europa, lavoro — e tre assi per sederti
          in un banco dell'emiciclo.
        </p>
      </div>

      <div className="enter enter-d3 mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
        <Button size="lg" onClick={onStart} className="w-full sm:w-auto">
          Inizia il test
          <ArrowRight className="size-4" strokeWidth={2} />
        </Button>
        {hasSaved ? (
          <Button
            size="lg"
            variant="outline"
            onClick={onResumeResult}
            className="w-full sm:w-auto"
          >
            Vedi l'ultimo esito
          </Button>
        ) : null}
      </div>

      <p className="enter enter-d4 mt-4 flex items-center gap-2 text-sm text-faint">
        <Clock3 className="size-3.5" strokeWidth={1.75} />
        Circa quattro minuti · puoi tornare indietro
      </p>

      <ul className="enter enter-d5 mt-12 grid gap-px overflow-hidden rounded-xl bg-line shadow-card sm:grid-cols-3">
        {[
          { k: "Economia", v: "Stato o mercato" },
          { k: "Società", v: "Diritti o tradizione" },
          { k: "Sovranità", v: "Europa o nazione" },
        ].map((item) => (
          <li key={item.k} className="bg-surface px-5 py-4">
            <p className="text-[0.68rem] font-medium uppercase tracking-[0.16em] text-faint">
              {item.k}
            </p>
            <p className="mt-1 font-display text-lg leading-snug">{item.v}</p>
          </li>
        ))}
      </ul>

      <p className="mt-10 max-w-lg text-xs leading-relaxed text-faint">
        Non è un sondaggio scientificamente campionato e non predice il voto.
        Le posizioni dei partiti sono una sintesi del dibattito 2022–2026
        (governo Meloni, ius scholae, reddito, premierato, Albania). Il centro
        esiste: se sei ibrido, te lo diciamo.
      </p>
    </div>
  );
}
