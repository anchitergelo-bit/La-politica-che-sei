//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BtLtuQYe.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D5Q0pSQZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D5Q0pSQZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CbuOJhMw.js"]
	}
} });
//#endregion
export { tsrStartManifest };
