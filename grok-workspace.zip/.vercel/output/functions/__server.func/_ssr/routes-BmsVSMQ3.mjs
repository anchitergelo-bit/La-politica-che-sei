import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ArrowRight, i as ChevronLeft, n as RotateCcw, r as Clock3 } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BmsVSMQ3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-sans font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-smooth focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-ink text-paper shadow-[0_1px_0_rgb(23_21_19_/_0.2)] hover:bg-ink-soft",
			outline: "bg-transparent text-ink ring-1 ring-ink/15 hover:bg-ink/[0.04] hover:ring-ink/25",
			ghost: "bg-transparent text-ink hover:bg-ink/[0.05]",
			inverse: "bg-paper text-ink hover:bg-paper-2"
		},
		size: {
			md: "h-11 rounded-lg px-5 text-sm",
			lg: "h-12 rounded-xl px-7 text-base",
			sm: "h-9 rounded-md px-3.5 text-sm",
			icon: "size-11 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var CRIMSON = "#8b2e2e";
var NAVY = "#1f3a5f";
var STONE = "#c4b8a6";
function round(n) {
	return Math.round(n * 100) / 100;
}
function buildSeats() {
	const rows = [
		11,
		14,
		17,
		21,
		25
	];
	const seats = [];
	rows.forEach((count, row) => {
		const radius = 52 + row * 16;
		for (let i = 0; i < count; i++) {
			const t = count === 1 ? .5 : i / (count - 1);
			const a = Math.PI - t * Math.PI;
			seats.push({
				x: round(200 + Math.cos(a) * radius),
				y: round(178 - Math.sin(a) * radius),
				t: round(t * 1e3) / 1e3,
				r: row === 0 ? 3.1 : 3.4
			});
		}
	});
	return seats;
}
var SEATS = buildSeats();
function seatFill(t) {
	if (t < .45) return mix(CRIMSON, STONE, t / .45);
	if (t > .55) return mix(STONE, NAVY, (t - .55) / .45);
	return STONE;
}
function mix(a, b, t) {
	const pa = hex(a);
	const pb = hex(b);
	const m = (i) => Math.round(pa[i] + (pb[i] - pa[i]) * t);
	return `rgb(${m(0)} ${m(1)} ${m(2)})`;
}
function hex(h) {
	return [
		parseInt(h.slice(1, 3), 16),
		parseInt(h.slice(3, 5), 16),
		parseInt(h.slice(5, 7), 16)
	];
}
function Hemicycle({ position, className, marked = true }) {
	const tUser = position === void 0 ? null : Math.min(1, Math.max(0, (position + 100) / 200));
	let closest = 0;
	if (tUser !== null) {
		let best = 1;
		SEATS.forEach((s, i) => {
			const d = Math.abs(s.t - tUser);
			if (d < best) {
				best = d;
				closest = i;
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 400 200",
		className: cn("w-full", className),
		role: "img",
		"aria-label": tUser === null ? "Emiciclo parlamentare vuoto" : "La tua posizione nell'emiciclo",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M 42 178 A 158 158 0 0 1 358 178",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.08",
				strokeWidth: "1"
			}),
			SEATS.map((seat, i) => {
				const isMark = marked && tUser !== null && i === closest;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: seat.x,
					cy: seat.y,
					r: isMark ? seat.r + 2.2 : seat.r,
					fill: isMark ? "var(--color-ink)" : seatFill(seat.t),
					opacity: isMark ? 1 : .92
				}, `${seat.x}-${seat.y}-${i}`);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "168",
				y: "176",
				width: "64",
				height: "8",
				rx: "1",
				fill: "var(--color-ink)",
				opacity: "0.88"
			})
		]
	});
}
function Landing({ onStart, hasSaved, onResumeResult }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-5 pb-16 pt-8 sm:px-8 sm:pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "enter flex items-baseline justify-between border-b border-line pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Emiciclo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.7rem] font-medium uppercase tracking-[0.18em] text-muted",
					children: "Politica italiana"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "enter enter-d1 mt-10 sm:mt-14",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hemicycle, {
					marked: false,
					className: "mx-auto max-w-md text-ink"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "enter enter-d2 mt-8 sm:mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[0.7rem] font-medium uppercase tracking-[0.18em] text-muted",
						children: "Test di orientamento"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-3 font-display text-[2.15rem] font-medium leading-[1.12] tracking-[-0.03em] text-ink sm:text-5xl",
						children: [
							"Di che parte sei,",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "italic",
								children: "davvero"
							}),
							"?"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-md text-[1.05rem] leading-relaxed text-muted",
						children: "Non un meme da social. Venti domande sul dibattito italiano di questi anni — tasse, migranti, 194, Europa, lavoro — e tre assi per sederti in un banco dell'emiciclo."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "enter enter-d3 mt-8 flex flex-col gap-3 sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					onClick: onStart,
					className: "w-full sm:w-auto",
					children: ["Inizia il test", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
						className: "size-4",
						strokeWidth: 2
					})]
				}), hasSaved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "outline",
					onClick: onResumeResult,
					className: "w-full sm:w-auto",
					children: "Vedi l'ultimo esito"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "enter enter-d4 mt-4 flex items-center gap-2 text-sm text-faint",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, {
					className: "size-3.5",
					strokeWidth: 1.75
				}), "Circa quattro minuti · puoi tornare indietro"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "enter enter-d5 mt-12 grid gap-px overflow-hidden rounded-xl bg-line shadow-card sm:grid-cols-3",
				children: [
					{
						k: "Economia",
						v: "Stato o mercato"
					},
					{
						k: "Società",
						v: "Diritti o tradizione"
					},
					{
						k: "Sovranità",
						v: "Europa o nazione"
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "bg-surface px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[0.68rem] font-medium uppercase tracking-[0.16em] text-faint",
						children: item.k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-lg leading-snug",
						children: item.v
					})]
				}, item.k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 max-w-lg text-xs leading-relaxed text-faint",
				children: "Non è un sondaggio scientificamente campionato e non predice il voto. Le posizioni dei partiti sono una sintesi del dibattito 2022–2026 (governo Meloni, ius scholae, reddito, premierato, Albania). Il centro esiste: se sei ibrido, te lo diciamo."
			})
		]
	});
}
var QUESTIONS = [
	{
		id: "flat-tax",
		tema: "Fisco",
		testo: "L'Italia dovrebbe introdurre una flat tax: un'aliquota unica, più bassa, per tutti i redditi.",
		nota: "È la bandiera storica della Lega e di parte del centro-destra.",
		polarity: 1,
		axes: {
			economico: 1,
			culturale: .1,
			sovranita: .15
		}
	},
	{
		id: "ius-scholae",
		tema: "Cittadinanza",
		testo: "Chi nasce in Italia o ci studia per un ciclo intero dovrebbe diventare cittadino con una procedura semplice, senza aspettare i diciotto anni.",
		nota: "Ius scholae / ius soli: spaccatura classica fra PD, AVS, M5S e il centro-destra.",
		polarity: -1,
		axes: {
			economico: .05,
			culturale: .7,
			sovranita: .55
		}
	},
	{
		id: "sicurezza",
		tema: "Sicurezza",
		testo: "Per stazioni, piazze e periferie servono più poteri alle forze dell'ordine, pene più certe e meno indulgenza verso reati di strada.",
		polarity: 1,
		axes: {
			economico: .1,
			culturale: .85,
			sovranita: .25
		}
	},
	{
		id: "salario-minimo",
		tema: "Lavoro",
		testo: "Serve un salario minimo legale, anche se sindacati e Confindustria preferiscono lasciare tutto ai contratti.",
		polarity: -1,
		axes: {
			economico: 1,
			culturale: .15,
			sovranita: 0
		}
	},
	{
		id: "famiglia",
		tema: "Famiglia",
		testo: "Lo Stato deve privilegiare la famiglia fondata sul matrimonio tra uomo e donna, non equiparare ogni forma di unione.",
		polarity: 1,
		axes: {
			economico: .05,
			culturale: 1,
			sovranita: .15
		}
	},
	{
		id: "clima",
		tema: "Ambiente",
		testo: "La transizione ecologica va accelerata anche se nel breve pesa su auto, industria e bollette.",
		polarity: -1,
		axes: {
			economico: .55,
			culturale: .45,
			sovranita: .1
		}
	},
	{
		id: "premierato",
		tema: "Istituzioni",
		testo: "Un premierato — presidente del Consiglio eletto, più stabile e più forte — renderebbe l'Italia meglio governabile.",
		nota: "Riforma costituzionale cara a Fratelli d'Italia; la sinistra la legge come rischio autoritario.",
		polarity: 1,
		axes: {
			economico: .1,
			culturale: .35,
			sovranita: .7
		}
	},
	{
		id: "reddito",
		tema: "Welfare",
		testo: "Uno strumento strutturale di reddito minimo (nello spirito del reddito di cittadinanza) va difeso: senza, troppe persone restano indietro.",
		polarity: -1,
		axes: {
			economico: 1,
			culturale: .2,
			sovranita: .05
		}
	},
	{
		id: "toghe",
		tema: "Giustizia",
		testo: "Separare le carriere di giudici e pubblici ministeri e ridurre il peso della magistratura sulla politica è una riforma urgente.",
		polarity: 1,
		axes: {
			economico: .15,
			culturale: .55,
			sovranita: .35
		}
	},
	{
		id: "194",
		tema: "Diritti",
		testo: "La legge 194 va applicata per intero: meno obiettori di fatto, più accesso reale all'interruzione di gravidanza.",
		polarity: -1,
		axes: {
			economico: .05,
			culturale: 1,
			sovranita: .05
		}
	},
	{
		id: "bruxelles",
		tema: "Europa",
		testo: "L'Italia deve recuperare sovranità su bilancio, confini e regole, anche a costo di uno scontro con Bruxelles.",
		polarity: 1,
		axes: {
			economico: .25,
			culturale: .2,
			sovranita: 1
		}
	},
	{
		id: "articolo-18",
		tema: "Lavoro",
		testo: "Va ripristinata una tutela forte contro i licenziamenti, nello spirito dell'articolo 18.",
		polarity: -1,
		axes: {
			economico: 1,
			culturale: .2,
			sovranita: 0
		}
	},
	{
		id: "autonomia",
		tema: "Autonomie",
		testo: "Le Regioni più efficienti devono poter tenere più tasse e gestire da sole sanità, scuola e infrastrutture.",
		nota: "Autonomia differenziata: priorità della Lega, osteggiata da M5S, PD e da gran parte del Sud.",
		polarity: 1,
		axes: {
			economico: .35,
			culturale: .1,
			sovranita: .7
		}
	},
	{
		id: "armi",
		tema: "Esteri",
		testo: "L'Italia deve ridurre la spesa militare e uscire dalla logica dei blocchi, privilegiando la diplomazia sulla spedizione di armi.",
		polarity: -1,
		axes: {
			economico: .15,
			culturale: .25,
			sovranita: .85
		}
	},
	{
		id: "nazione",
		tema: "Identità",
		testo: "L'Italia deve smettere di vergognarsi della propria storia nazionale e mettere bandiera, tradizione e identità al centro della vita pubblica.",
		polarity: 1,
		axes: {
			economico: 0,
			culturale: .75,
			sovranita: .7
		}
	},
	{
		id: "casa",
		tema: "Casa",
		testo: "Affitti, case popolari, limiti agli affitti brevi: la casa è un diritto, non può restare in mano al solo mercato.",
		polarity: -1,
		axes: {
			economico: .9,
			culturale: .2,
			sovranita: .05
		}
	},
	{
		id: "nucleare",
		tema: "Energia",
		testo: "L'Italia deve tornare al nucleare per avere energia stabile e meno dipendenza dal gas.",
		polarity: 1,
		axes: {
			economico: .55,
			culturale: .15,
			sovranita: .35
		}
	},
	{
		id: "scuola",
		tema: "Scuola",
		testo: "A scuola non si deve parlare di identità di genere: l'educazione dei figli spetta alla famiglia, non allo Stato.",
		polarity: 1,
		axes: {
			economico: 0,
			culturale: 1,
			sovranita: .15
		}
	},
	{
		id: "stato-economia",
		tema: "Economia",
		testo: "Lo Stato deve tornare a pesare di più nell'economia: partecipazioni pubbliche, controllo dei prezzi, nazionalizzazioni se serve.",
		polarity: -1,
		axes: {
			economico: 1,
			culturale: .1,
			sovranita: .2
		}
	},
	{
		id: "migranti",
		tema: "Confini",
		testo: "L'Italia deve respingere i barconi, esternalizzare i centri (Albania o Africa) e rendere più difficile lo sbarco.",
		polarity: 1,
		axes: {
			economico: .15,
			culturale: .55,
			sovranita: .9
		}
	}
];
var LIKERT_VALUES = [
	-2,
	-1,
	0,
	1,
	2
];
var AXIS_META = {
	economico: {
		label: "Economia",
		left: "Stato e redistribuzione",
		right: "Mercato e tasse basse",
		blurb: "Chi deve pesare di più: la spesa pubblica, i sindacati, il welfare — o impresa, partite IVA, taglio del cuneo."
	},
	culturale: {
		label: "Società",
		left: "Diritti e laicità",
		right: "Tradizione e ordine",
		blurb: "Famiglia, scuola, 194, identità di genere, memoria pubblica: il perimetro del lecito e del normale."
	},
	sovranita: {
		label: "Sovranità",
		left: "Europa e alleanze",
		right: "Nazione e confini",
		blurb: "Bruxelles, NATO, migranti, autonomie: quanto l'Italia deve vincolarsi all'esterno e quanto chiudere il perimetro."
	}
};
var END_LABELS = {
	[-2]: "No",
	[-1]: "Più no",
	[0]: "Neutrale",
	[1]: "Più sì",
	[2]: "Sì"
};
function QuestionView({ index, value, onChoose, onBack }) {
	const q = QUESTIONS[index];
	const total = QUESTIONS.length;
	const progress = (index + (value !== void 0 ? 1 : 0)) / total * 100;
	if (!q) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-5 pb-10 pt-6 sm:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				className: "size-11 shrink-0",
				onClick: onBack,
				"aria-label": index === 0 ? "Torna all'inizio" : "Domanda precedente",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[0.7rem] font-medium uppercase tracking-[0.16em] text-muted",
						children: q.tema
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-sans text-xs tabular-nums text-faint",
						children: [
							index + 1,
							" / ",
							total
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-1 overflow-hidden rounded-full bg-paper-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-ink transition-[width] duration-fast ease-smooth",
						style: { width: `${progress}%` }
					})
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "enter mt-10 flex flex-1 flex-col sm:mt-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-[1.65rem] font-medium leading-snug tracking-[-0.02em] sm:text-[2rem]",
					children: q.testo
				}),
				q.nota ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-lg text-sm leading-relaxed text-muted",
					children: q.nota
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 sm:mt-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-5 min-h-6 text-center text-sm font-medium text-ink",
							"aria-live": "polite",
							children: value !== void 0 ? END_LABELS[value] : "Scegli una posizione"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							role: "radiogroup",
							"aria-label": "Quanto sei d'accordo",
							className: "flex items-end justify-between gap-1 sm:gap-2",
							children: LIKERT_VALUES.map((v) => {
								const selected = value === v;
								const size = v === 0 ? "size-11 sm:size-12" : v === -1 || v === 1 ? "size-12 sm:size-14" : "size-14 sm:size-16";
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									role: "radio",
									"aria-checked": selected,
									"aria-label": END_LABELS[v],
									onClick: () => onChoose(v),
									className: "flex min-h-11 min-w-11 flex-col items-center gap-2 rounded-2xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("rounded-full border transition-[background-color,border-color,transform,box-shadow] duration-150 ease-smooth", size, selected ? "border-ink bg-ink shadow-[0_0_0_4px_rgb(23_21_19_/_0.12)]" : "border-ink/25 bg-surface hover:border-ink/50 hover:bg-paper-2") })
								}, v);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex justify-between text-[0.7rem] font-medium uppercase tracking-[0.14em] text-faint",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "In disaccordo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "D'accordo" })]
						})
					]
				})
			]
		}, q.id)]
	});
}
/** Posizioni indicative sul dibattito 2022–2026, non un sondaggio. Scala −100…+100. */
var PARTIES = [
	{
		id: "avs",
		name: "Alleanza Verdi e Sinistra",
		short: "AVS",
		family: "Sinistra radicale",
		economico: -74,
		culturale: -80,
		sovranita: -58,
		blurb: "Ecologista, femminista, pacifista. Salario minimo, 194 piena, no al nucleare, scettica sulla NATO."
	},
	{
		id: "pd",
		name: "Partito Democratico",
		short: "PD",
		family: "Centro-sinistra",
		economico: -40,
		culturale: -58,
		sovranita: -52,
		blurb: "Europeista e atlantista. Ius scholae, welfare, transizione; più cauto su nazionalizzazioni e reddito universale."
	},
	{
		id: "m5s",
		name: "Movimento 5 Stelle",
		short: "M5S",
		family: "Populismo di sinistra",
		economico: -58,
		culturale: -16,
		sovranita: -6,
		blurb: "Reddito, ambiente, pace. Ostile all'autonomia differenziata; più trasversale sui temi etici e sull'Europa."
	},
	{
		id: "azione",
		name: "Azione / +Europa",
		short: "Azione",
		family: "Centro riformista",
		economico: 24,
		culturale: -46,
		sovranita: -64,
		blurb: "Liberale, atlantista, nucleare e mercato. Progressista sui diritti, intransigente con i conti pubblici."
	},
	{
		id: "fi",
		name: "Forza Italia",
		short: "FI",
		family: "Centro-destra liberale",
		economico: 50,
		culturale: 22,
		sovranita: 6,
		blurb: "Basse tasse, impresa, NATO e UE. Conservatore morbido su famiglia e ordine, europeista nel metodo."
	},
	{
		id: "lega",
		name: "Lega",
		short: "Lega",
		family: "Destra sovranista",
		economico: 30,
		culturale: 58,
		sovranita: 80,
		blurb: "Confini, autonomia regionale, flat tax. Scettica su Bruxelles e sui diritti civili, più ambigua sulla NATO."
	},
	{
		id: "fdi",
		name: "Fratelli d'Italia",
		short: "FdI",
		family: "Destra nazionale",
		economico: 40,
		culturale: 74,
		sovranita: 76,
		blurb: "Nazione, famiglia, ordine, premierato. Mercato con Stato strategico; dura su migranti e identità."
	}
];
var AXES$1 = [
	"economico",
	"culturale",
	"sovranita"
];
var BANDS = [
	{
		id: "estrema-sinistra",
		max: -68
	},
	{
		id: "sinistra",
		max: -42
	},
	{
		id: "centro-sinistra",
		max: -16
	},
	{
		id: "centro",
		max: 16
	},
	{
		id: "centro-destra",
		max: 42
	},
	{
		id: "destra",
		max: 68
	},
	{
		id: "destra-nazionale",
		max: 200
	}
];
function bandFromScore(overall) {
	for (const band of BANDS) if (overall <= band.max) return band.id;
	return "destra-nazionale";
}
function scoreQuiz(answers) {
	const contrib = {
		economico: 0,
		culturale: 0,
		sovranita: 0
	};
	const weight = {
		economico: 0,
		culturale: 0,
		sovranita: 0
	};
	for (const q of QUESTIONS) {
		const answer = answers[q.id];
		if (answer === void 0) continue;
		for (const axis of AXES$1) {
			const w = q.axes[axis];
			contrib[axis] += answer * q.polarity * w;
			weight[axis] += 2 * w;
		}
	}
	const axes = {
		economico: 0,
		culturale: 0,
		sovranita: 0
	};
	for (const axis of AXES$1) axes[axis] = weight[axis] === 0 ? 0 : 100 * contrib[axis] / weight[axis];
	const overall = axes.economico * .38 + axes.culturale * .4 + axes.sovranita * .22;
	const matches = rankParties(axes);
	return {
		overall,
		axes,
		band: bandFromScore(overall),
		matches,
		answers
	};
}
function rankParties(axes) {
	return PARTIES.map((party) => {
		const dist = Math.hypot(axes.economico - party.economico, axes.culturale - party.culturale, axes.sovranita - party.sovranita);
		return {
			party,
			score: Math.max(0, Math.min(100, 100 * (1 - dist / Math.hypot(200, 200, 200))))
		};
	}).sort((a, b) => b.score - a.score);
}
var BAND_COPY = {
	"estrema-sinistra": {
		title: "Sinistra radicale",
		kicker: "Il banco è in fondo a sinistra",
		body: "Redistribuzione, diritti civili, pace e transizione: lo Stato deve spostare il baricentro, non accomodarsi al mercato. Nell'emiciclo odierno sei vicino ad AVS e alla sinistra di conflitto."
	},
	sinistra: {
		title: "Sinistra",
		kicker: "Welfare, diritti, Europa sociale",
		body: "Non sei per la rivoluzione, ma il mercato da solo non ti basta. Salario, casa, 194, cittadinanza: la politica deve correggere. Il PD di Schlein e i Verdi ti somigliano più di Calenda o Meloni."
	},
	"centro-sinistra": {
		title: "Centro-sinistra",
		kicker: "Riformista, europeista, laico",
		body: "Preferisci correzioni al sistema, non un cambio di regime. Diritti e welfare sì, nazionalizzazioni e sovranismo no. È il territorio storico del PD, con sconfinamenti verso M5S o il centro riformista."
	},
	centro: {
		title: "Centro",
		kicker: "Né pullover rosso né tricolore in giacca",
		body: "Le tue risposte non si fanno catturare da un solo polo. Può essere pragmatismo, ibridazione (mercato + diritti, o Stato + tradizione) o semplice rifiuto delle tribù. In Parlamento oggi è un posto scomodo."
	},
	"centro-destra": {
		title: "Centro-destra",
		kicker: "Impresa, ordine, europeismo cauto",
		body: "Tasse più basse, legalità, famiglia come cornice — senza spezzare i ponti con Bruxelles e la NATO. È il registro di Forza Italia, e di chi nel centro-destra non vuole la guerra culturale tutti i giorni."
	},
	destra: {
		title: "Destra",
		kicker: "Confini, identità, governo forte",
		body: "Sovranità, sicurezza, tradizione: lo Stato c'è, ma per chi sta dentro il perimetro. Lega e Fratelli d'Italia ti sono più vicini del PD; l'Europa è un vincolo da ridiscutere, non una patria."
	},
	"destra-nazionale": {
		title: "Destra nazionale",
		kicker: "Nazione prima di tutto",
		body: "Identità, ordine, premierato, respingimenti: il quadro è quello di Fratelli d'Italia, con la Lega a fare da cassa di risonanza sovranista. La sinistra istituzionale ti appare un'altra Repubblica."
	}
};
function profileNote(result) {
	const { economico, culturale, sovranita } = result.axes;
	const econLeft = economico < -20;
	const econRight = economico > 20;
	const cultLeft = culturale < -20;
	const cultRight = culturale > 20;
	const euro = sovranita < -20;
	const sovran = sovranita > 20;
	if (econLeft && cultRight) return "Profilo ibrido: interventista in economia, conservatore sui costumi. In Italia è il terreno di una parte del M5S e di un elettorato popolare che non si riconosce nel PD laico né nel liberismo di Azione.";
	if (econRight && cultLeft) return "Profilo liberale: mercato e diritti, NATO e laicità. È la nicchia di Azione e +Europa — influente nel dibattito, stretta alle urne.";
	if (econLeft && cultLeft && euro) return "Coerente a sinistra su tutti e tre gli assi: spesa, diritti, Europa. Pochi salti mortali, molte distanze dalla maggioranza di governo.";
	if (econRight && cultRight && sovran) return "Coerente a destra su tutti e tre gli assi: fisco, costumi, nazione. È il blocco che ha vinto nel 2022, con sfumature fra FI, Lega e FdI.";
	if (sovran && cultLeft) return "Sovranista sui confini, progressista sui diritti: combinazione rara nei partiti, più frequente fra gli elettori delusi da entrambi i poli.";
	if (euro && cultRight) return "Europeista e socialmente conservatore: il vecchio centro-destra berlusconiano, oggi minoranza dentro una destra più identitaria.";
	if (Math.abs(result.overall) < 12) return "Le distanze fra gli assi si compensano: il verdetto «centro» nasconde magari una sinistra economica e una destra culturale, o il contrario. Guarda le tre barre, non solo il titolo.";
	return "Il titolo è una sintesi. Le tre barre sotto dicono se sei lineare o se, come succede spesso in Italia, sei di una parte sull'economia e dell'altra sui costumi.";
}
function overallLabel(score) {
	if (score < -8) return "sinistra";
	if (score > 8) return "destra";
	return "centro";
}
var AXES = [
	"economico",
	"culturale",
	"sovranita"
];
function Results({ result, onRetake }) {
	const copy = BAND_COPY[result.band];
	const side = overallLabel(result.overall);
	const top = result.matches.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-2xl px-5 pb-20 pt-8 sm:px-8 sm:pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-baseline justify-between border-b border-line pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Emiciclo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.7rem] font-medium uppercase tracking-[0.18em] text-muted",
					children: "Esito"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "enter mt-10 text-[0.7rem] font-medium uppercase tracking-[0.18em] text-muted",
				children: copy.kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "enter enter-d1 mt-3 font-display text-[2.35rem] font-medium leading-[1.1] tracking-[-0.03em] sm:text-5xl",
				children: copy.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "enter enter-d2 mt-2 font-display text-xl italic text-muted",
				children: [
					"Per la politica italiana sei di ",
					side,
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "enter enter-d3 mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hemicycle, {
					position: result.overall,
					className: "mx-auto max-w-md"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spectrum, { score: result.overall })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "enter enter-d4 mt-8 text-[1.05rem] leading-relaxed text-ink-soft",
				children: copy.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: profileNote(result)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[0.7rem] font-medium uppercase tracking-[0.16em] text-muted",
					children: "Tre assi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-col gap-6",
					children: AXES.map((axis) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AxisBar, {
						axis,
						value: result.axes[axis]
					}, axis))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[0.7rem] font-medium uppercase tracking-[0.16em] text-muted",
						children: "Il banco più vicino"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-px overflow-hidden rounded-xl bg-line shadow-card",
						children: top.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-4 bg-surface px-4 py-4 sm:px-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-0.5 w-8 shrink-0 font-display text-lg tabular-nums", i === 0 ? "text-ink" : "text-faint"),
								children: Math.round(m.score)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-baseline gap-x-2 gap-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: m.party.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-faint",
										children: m.party.family
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-relaxed text-muted",
									children: m.party.blurb
								})]
							})]
						}, m.party.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-faint",
						children: "Affinità 0–100 sulla distanza fra i tuoi tre assi e la posizione indicativa del partito. Non è un consiglio di voto."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 flex flex-col gap-3 sm:flex-row",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					onClick: onRetake,
					className: "w-full sm:w-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
						className: "size-4",
						strokeWidth: 2
					}), "Rifai il test"]
				})
			})
		]
	});
}
function Spectrum({ score }) {
	const left = (score + 100) / 200 * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto mt-2 max-w-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative h-1.5 overflow-hidden rounded-full bg-linear-to-r from-crimson via-paper-3 to-navy",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-ink ring-2 ring-paper",
				style: { left: `${left}%` }
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex justify-between text-[0.65rem] font-medium uppercase tracking-[0.14em] text-faint",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sinistra" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums text-ink/70",
					children: fmt(score)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Destra" })
			]
		})]
	});
}
function AxisBar({ axis, value }) {
	const meta = AXIS_META[axis];
	const mid = 50;
	const pos = (value + 100) / 200 * 100;
	const from = Math.min(mid, pos);
	const width = Math.abs(pos - mid);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: meta.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tabular-nums text-muted",
				children: fmt(value)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 text-xs text-faint",
			children: meta.blurb
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mt-3 h-2 rounded-full bg-paper-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("bar-in absolute top-0 h-2 rounded-full", value < 0 ? "bg-crimson origin-right" : "bg-navy origin-left"),
				style: {
					left: `${from}%`,
					width: `${Math.max(width, value === 0 ? 0 : 1.5)}%`
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-ink/30" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1.5 flex justify-between text-[0.65rem] text-faint",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: meta.left }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: meta.right })]
		})
	] });
}
function fmt(n) {
	const v = Math.round(n);
	if (v > 0) return `+${v}`;
	return `${v}`;
}
var STORAGE_KEY = "emiciclo-result-v1";
function Home() {
	const [screen, setScreen] = (0, import_react.useState)("home");
	const [index, setIndex] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [result, setResult] = (0, import_react.useState)(null);
	const [saved, setSaved] = (0, import_react.useState)(null);
	const advanceRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (!raw) return;
			const parsed = JSON.parse(raw);
			if (parsed && typeof parsed.overall === "number" && parsed.band) setSaved(parsed);
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			if (advanceRef.current !== null) window.clearTimeout(advanceRef.current);
		};
	}, []);
	function clearAdvance() {
		if (advanceRef.current !== null) {
			window.clearTimeout(advanceRef.current);
			advanceRef.current = null;
		}
	}
	function start() {
		clearAdvance();
		setAnswers({});
		setIndex(0);
		setResult(null);
		setScreen("quiz");
	}
	function choose(value) {
		const q = QUESTIONS[index];
		if (!q) return;
		const from = index;
		const nextAnswers = {
			...answers,
			[q.id]: value
		};
		setAnswers(nextAnswers);
		clearAdvance();
		advanceRef.current = window.setTimeout(() => {
			if (from + 1 >= QUESTIONS.length) {
				const scored = scoreQuiz(nextAnswers);
				setResult(scored);
				setSaved(scored);
				try {
					localStorage.setItem(STORAGE_KEY, JSON.stringify(scored));
				} catch {}
				setScreen("results");
			} else setIndex(from + 1);
		}, 160);
	}
	function back() {
		clearAdvance();
		if (index === 0) {
			setScreen("home");
			return;
		}
		setIndex((i) => i - 1);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "paper-grain min-h-dvh bg-paper text-ink",
		children: [
			screen === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {
				onStart: start,
				hasSaved: Boolean(saved),
				onResumeResult: () => {
					if (saved) {
						setResult(saved);
						setScreen("results");
					}
				}
			}) : null,
			screen === "quiz" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionView, {
				index,
				value: answers[QUESTIONS[index]?.id ?? ""],
				onChoose: choose,
				onBack: back
			}) : null,
			screen === "results" && result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {
				result,
				onRetake: start
			}) : null
		]
	});
}
//#endregion
export { Home as component };
